package com.example.monukumar.monukumar;

import android.app.ProgressDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.io.IOException;
import java.util.UUID;

public class Main2Activity extends AppCompatActivity {
    String address=null;
    private ProgressDialog pro;
    UUID u=UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    BluetoothSocket bs=null;
    BluetoothAdapter ba=null;
    boolean isBTConnected=false;
    Button bu1,bu2,bu3,bu4,bu5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        Intent i=getIntent();
        address=i.getStringExtra(MainActivity.EXTRA_MESSAGE);
        bu1=(Button)(findViewById(R.id.b1));
        bu2=(Button)(findViewById(R.id.b2));
        bu3=(Button)(findViewById(R.id.b3));
        bu4=(Button)(findViewById(R.id.b4));
        bu5=(Button)(findViewById(R.id.b5));
        new connect().execute();
        bu1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                forward();
            }
        });
        bu2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                backward();
            }
        });
        bu3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                right();
            }
        });
        bu4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                left();
            }
        });
        bu5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopp();
            }
        });



    }
    void stopp(){
        if(bs!=null){
            try{
                bs.getOutputStream().write("5".getBytes());
            }
            catch(IOException e){
                Toast.makeText(getApplicationContext(),"Error" ,Toast.LENGTH_SHORT).show();
            }
        }

    }
    void backward(){
        if(bs!=null){
            try{
                bs.getOutputStream().write("2".getBytes());
            }
            catch(IOException e){
                Toast.makeText(getApplicationContext(),"Error" ,Toast.LENGTH_SHORT).show();
            }
        }

    }
    void forward(){
        if(bs!=null){
            try{
                bs.getOutputStream().write("1".getBytes());
            }
            catch(IOException e){
                Toast.makeText(getApplicationContext(),"Error" ,Toast.LENGTH_SHORT).show();
            }
        }

    }
    void left(){
        if(bs!=null){
            try{
                bs.getOutputStream().write("3".getBytes());
            }
            catch(IOException e){
                Toast.makeText(getApplicationContext(),"Error" ,Toast.LENGTH_SHORT).show();
            }
        }

    }
    void right(){
        if(bs!=null){
            try{
                bs.getOutputStream().write("4".getBytes());
            }
            catch(IOException e){
                Toast.makeText(getApplicationContext(),"Error" ,Toast.LENGTH_SHORT).show();
            }
        }

    }
    private  class connect extends AsyncTask<Void, Void, Void>
    {
     private boolean success=true;

        @Override
        protected void onPreExecute() {
           pro= ProgressDialog.show(Main2Activity.this, "Connecting.."," ");
        }

        @Override
        protected Void doInBackground(Void... params) {
            try{
                if (bs == null || !isBTConnected)
                {
                    ba = BluetoothAdapter.getDefaultAdapter();//get the mobile bluetooth device
                    BluetoothDevice dispositivo = ba.getRemoteDevice(address);//connects to the device's address and checks if it's available
                    bs = dispositivo.createInsecureRfcommSocketToServiceRecord(u);//create a RFCOMM (SPP) connection
                    BluetoothAdapter.getDefaultAdapter().cancelDiscovery();
                    bs.connect();//start connection
                }
            }
            catch(IOException e){
                success=false;
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            if(!success){
                Toast.makeText(getApplicationContext(),"failed",Toast.LENGTH_SHORT).show();
            }
            else{
                Toast.makeText(getApplicationContext(),"Connected",Toast.LENGTH_SHORT).show();
                success=true;
            }
            pro.dismiss();
        }
    }



}
