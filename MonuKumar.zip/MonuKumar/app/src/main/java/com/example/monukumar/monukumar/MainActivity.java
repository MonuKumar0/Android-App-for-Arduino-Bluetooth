package com.example.monukumar.monukumar;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;

import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;



public class MainActivity extends AppCompatActivity {
    public final static String EXTRA_MESSAGE = "Monu Kumar";
    @Override


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

       final ListView lv = (ListView) (findViewById(R.id.listView));
        final BluetoothAdapter ba = BluetoothAdapter.getDefaultAdapter();

        ArrayList list = new ArrayList();

        if (ba.getBondedDevices().size() > 0) {
            for (BluetoothDevice bt : ba.getBondedDevices()) {
                list.add(bt.getName() + "\n" + bt.getAddress());
            }
        }
        final ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, list);
        lv.setAdapter(adapter);
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView av, View v, int arg2, long arg3) {

                    String info = ((TextView) v).getText().toString();
                String address = info.substring(info.length() - 17);

                Intent i=new Intent(MainActivity.this,Main2Activity.class);
i.putExtra(EXTRA_MESSAGE,address);
                startActivity(i);
            }

        });


    }
}
